package adapter;

/**
 * Common Interface which has methods to be called from Client
 * @author mnatesan
 *
 */
public interface ITarget {
	
	/**
	 * request method from client
	 */
	public void request();
}
