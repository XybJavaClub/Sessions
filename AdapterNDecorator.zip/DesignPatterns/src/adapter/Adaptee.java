package adapter;

/**
 * Adaptee class which has different method name but same purpose which is called from client
 * @author mnatesan
 *
 */
public class Adaptee {
	/**
	 * special request method
	 */
	public void specialRequest() {
		System.out.println("Adaptee speical request");
	}
}
