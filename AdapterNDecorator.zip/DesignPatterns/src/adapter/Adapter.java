package adapter;

/**
 * Adapter class to adapt the Adaptee class for the client request method
 * @author mnatesan
 *
 */
public class Adapter implements ITarget {
	
	Adaptee adaptee = null;

	/**
	 * Passes the adaptee through constructor which is dependency injection
	 * @param adaptee
	 */
	public Adapter (Adaptee adaptee) {
		this.adaptee = adaptee;
	}
	
	/**
	 *regular request method calls the Adaptee.specialRequest
	 */
	@Override
	public void request() {
		this.adaptee.specialRequest();

	}

}
