package decorator;


/**
 * Caramol Concreate Decorator class with has Beverage and is the Beverage
 * @author mnatesan
 *
 */
public class Caramol extends AddonDecorator {

	Beverage beverage;
	
	/**
	 * Has the Beverage
	 * @param beverage
	 */
	public Caramol(Beverage beverage) {
		this.beverage = beverage;
	}
	
	/**
	 *get the cost of Beverage and its own cost
	 */
	@Override
	public int cost() {
		return this.beverage.cost() + 2;
	}

}
