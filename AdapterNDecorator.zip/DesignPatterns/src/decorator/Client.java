package decorator;

public class Client {
	//other examples for Decorator -
	//InputStream, FileInputStream, BufferInputStream, LineNumberInputStream..
	public static void main(String arg[]) {
		Beverage beverage = new Experso();
		AddonDecorator decorator = new Caramol(beverage);
		System.out.println("Experso cost " + beverage.cost());
		System.out.println("Experso with Caramol cost " + decorator.cost());
	}
}
