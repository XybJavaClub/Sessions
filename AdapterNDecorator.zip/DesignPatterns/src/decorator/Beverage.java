package decorator;

/**
 * Beverage is the component class
 * @author mnatesan
 *
 */
public abstract class Beverage {
	public abstract int cost(); 
}
