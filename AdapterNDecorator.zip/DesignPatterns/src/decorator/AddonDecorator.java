package decorator;

/**
 * AddonDecorator is the Decorator class and it extends the Beverage
 * @author mnatesan
 *
 */
public abstract class AddonDecorator extends Beverage {
	public abstract int cost();
}
