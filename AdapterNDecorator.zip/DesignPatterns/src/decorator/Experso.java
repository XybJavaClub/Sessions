package decorator;

/**
 * Experson is the concrete component class and it has its cost
 * @author mnatesan
 *
 */
public class Experso extends Beverage {

	/**
	 *Cost of Experso
	 */
	@Override
	public int cost() {
		return 5;
	}

}
